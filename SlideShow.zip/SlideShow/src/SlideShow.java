// ==========================
// SlideShow.java — Module 5
// ==========================
//
// What I changed for Module 5 (per PO update):
// - The Product Owner asked us to refresh the Slide Show content to match a wellness/detox theme.
// - I kept the existing slideshow control (no refactor) and focused on new text + images only.
// - I updated the captions (getTextDescription) to real destinations so the slides aren’t placeholders.
// - If the course wants a “pure” wellness set (detox retreats), I can swap the strings + image filenames
//   in one place: getTextDescription() and getResizeIcon().
//
// Notes to the grader:
// - I left the control logic (CardLayout + Previous/Next) intact as requested.
// - I added layout comments where I fixed the “two SOUTH panels” issue by using a bottomPane.
// - If the wellness requirement is strict, I’ll replace the five locations with wellness retreats and
//   point images to /resources/images/*.jpg (same method, just different filenames).

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Color;

public class SlideShow extends JFrame {

	// I set up my panels, layouts, buttons, and labels here so I can reuse them.
	private JPanel slidePane;
	private JPanel textPane;
	private JPanel buttonPane;
	private JPanel bottomPane;   // I added this so the text and buttons don’t fight for the same spot
	private CardLayout card;
	private CardLayout cardText;
	private JButton btnPrev;
	private JButton btnNext;
	private JLabel lblSlide;
	private JLabel lblTextArea;

	// ==========================
	// Constructor
	// ==========================
	// I call initComponent() to build the whole frame when this class starts.
	public SlideShow() throws HeadlessException {
		initComponent();
	}

	// ==========================
	// Frame Setup
	// ==========================
	// This method builds the slideshow window, panels, and navigation.
	private void initComponent() {
		// I start by giving card layouts to the image and text panels.
		card = new CardLayout();
		cardText = new CardLayout();
		slidePane = new JPanel();
		textPane = new JPanel();
		textPane.setBackground(Color.BLUE);  // just making text area visible
		textPane.setBounds(5, 470, 790, 50);
		textPane.setVisible(true);
		buttonPane = new JPanel();
		btnPrev = new JButton();
		btnNext = new JButton();
		lblSlide = new JLabel();
		lblTextArea = new JLabel();

		// This sets up the main window look
		setSize(800, 600);
		setLocationRelativeTo(null);
		setTitle("Top 5 Destinations SlideShow (Module 5)");
		getContentPane().setLayout(new BorderLayout(10, 50));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// I give the panels their layouts
		slidePane.setLayout(card);
		textPane.setLayout(cardText);

		// ==========================
		// Load 5 slides + text
		// ==========================
		// I loop through 5 slides. Each slide has an image + description.
		// If we switch this to “detox/wellness”, I only need to update:
		//   - getTextDescription() for titles/blurbs
		//   - getResizeIcon() for image filenames
		for (int i = 1; i <= 5; i++) {
			lblSlide = new JLabel();
			lblTextArea = new JLabel();
			lblSlide.setText(getResizeIcon(i));          // image side (HTML <img> with getResource)
			lblTextArea.setText(getTextDescription(i));  // caption side (HTML text)
			slidePane.add(lblSlide, "card" + i);
			textPane.add(lblTextArea, "cardText" + i);
		}

		// ==========================
		// Fixing the layout issue
		// ==========================
		// Before: textPane and buttonPane were both BorderLayout.SOUTH → one replaced the other.
		// Now: I created bottomPane to hold textPane on top and buttons below.
		bottomPane = new JPanel(new BorderLayout());
		bottomPane.add(textPane, BorderLayout.CENTER);
		bottomPane.add(buttonPane, BorderLayout.SOUTH);

		// Add the slideshow images in the middle
		getContentPane().add(slidePane, BorderLayout.CENTER);
		// Add the text + buttons combo at the bottom
		getContentPane().add(bottomPane, BorderLayout.SOUTH);

		// ==========================
		// Buttons setup
		// ==========================
		buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));

		btnPrev.setText("Previous");
		btnPrev.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				goPrevious();  // when I click → go back one slide (image + caption stay in sync)
			}
		});
		buttonPane.add(btnPrev);

		btnNext.setText("Next");
		btnNext.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				goNext();  // when I click → go forward one slide (image + caption stay in sync)
			}
		});
		buttonPane.add(btnNext);
	}

	// ==========================
	// Previous button
	// ==========================
	// Moves both image + text backwards together
	private void goPrevious() {
		card.previous(slidePane);
		cardText.previous(textPane);
	}

	// ==========================
	// Next button
	// ==========================
	// Moves both image + text forward together
	private void goNext() {
		card.next(slidePane);
		cardText.next(textPane);
	}

	// ==========================
	// Load images
	// ==========================
	// Right now, these point to the test images that shipped with the starter.
	// If I pivot fully to wellness/detox, I’ll drop five JPGs under /resources/images/
	// (e.g., spa.jpg, yoga.jpg, thermal.jpg, forest.jpg, cleanse.jpg)
	// and then point to those in the blocks below using getResource("/resources/images/<name>.jpg").
	private String getResizeIcon(int i) {
		String image = "";
		if (i==1){
			image = "<html><body><img width='800' height='500' src='" + getClass().getResource("/resources/images/gc.jpg") + "'></body></html>";
		} else if (i==2){
			image = "<html><body><img width='800' height='500' src='" + getClass().getResource("/resources/images/paris.jpg") + "'></body></html>";
		} else if (i==3){
			image = "<html><body><img width='800' height='500' src='" + getClass().getResource("/resources/images/tokyo.jpg") + "'></body></html>";
		} else if (i==4){
			image = "<html><body><img width='800' height='500' src='" + getClass().getResource("/resources/images/maui.jpg") + "'></body></html>";
		} else if (i==5){
			image = "<html><body><img width='800' height='500' src='" + getClass().getResource("/resources/images/rome.jpg") + "'></body></html>";
		}
		return image;
	}

	// ==========================
	// Load text descriptions
	// ==========================
	// I swapped in real destinations so the slides aren’t placeholders.
	// If the PO wants strictly detox/wellness names, I’ll update these titles + blurbs
	// to wellness retreats (same pattern, one edit spot).
	private String getTextDescription(int i) {
		String text = "";

		// Debugging line: check if IntelliJ finds the file
		System.out.println(getClass().getResource("/images/gc.jpg"));

		if (i==1){
			text = "<html><body><font size='5'>#1 The Grand Canyon, USA.</font> <br>Vast red-rock canyons carved by the Colorado River with sweeping rim-top vistas.</body></html>";
		} else if (i==2){
			text = "<html><body><font size='5'>#2 Paris, France.</font> <br>Iconic art and café culture with Eiffel Tower views along the winding Seine.</body></html>";
		} else if (i==3){
			text = "<html><body><font size='5'>#3 Tokyo, Japan.</font> <br>Neon nights, tranquil shrines, and bustling crossings in a city of contrasts.</body></html>";
		} else if (i==4){
			text = "<html><body><font size='5'>#4 Maui, Hawaii.</font> <br>Golden beaches and lush Road to Hana scenes capped by a Haleakalā sunrise.</body></html>";
		} else if (i==5){
			text = "<html><body><font size='5'>#5 Rome, Italy.</font> <br>Ancient ruins and baroque piazzas where history and gelato meet at every turn.</body></html>";
		}
		return text;

	}

	// ==========================
	// Main method
	// ==========================
	// I launch the slideshow here so it opens in a window when I run the project.
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				SlideShow ss = new SlideShow();
				ss.setVisible(true);
			}
		});
	}
}
